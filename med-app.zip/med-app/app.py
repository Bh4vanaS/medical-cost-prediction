import streamlit as st
import numpy as np
import joblib

# Load saved model and scaler
model = joblib.load("linear_regression_model.pkl")
scaler = joblib.load("scaler.pkl")

# App title
st.title("💰 Medical Expense Predictor")

# Input fields
st.header("Enter Patient Details")

age = st.number_input("Age", min_value=0, max_value=100, step=1)
bmi = st.number_input("BMI", format="%.2f")
children = st.number_input("Number of Children", min_value=0, step=1)

sex = st.selectbox("Sex", ["female", "male"])
smoker = st.selectbox("Smoker", ["no", "yes"])
region = st.selectbox("Region", ["southwest", "southeast", "northwest", "northeast"])

# Encode categorical variables
sex_male = 1 if sex == "male" else 0
smoker_yes = 1 if smoker == "yes" else 0

# Only include region columns used in training (drop_first=True)
region_northwest = 1 if region == "northwest" else 0
region_southeast = 1 if region == "southeast" else 0
# Note: 'southwest' is base case (all 0s), 'northeast' was dropped during training

# Combine input features in the correct order (7 features)
input_data = np.array([[age, bmi, children, sex_male, smoker_yes,
                        region_northwest, region_southeast]])

# Standardize numeric features
input_data[:, :3] = scaler.transform(input_data[:, :3])

# Predict
if st.button("Predict Medical Expense"):
    prediction = model.predict(input_data)[0]
    st.success(f"Estimated Medical Expense: ₹{prediction:,.2f}")
